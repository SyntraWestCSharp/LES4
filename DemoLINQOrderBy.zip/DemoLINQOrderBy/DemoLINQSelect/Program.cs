﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DemoLINQSelect
{
    enum Gender 
    {
        MALE,
        FEMALE,
        TRANSGENDER,
        HERMAFRODITE,
        UNDEFINED
    }
    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public byte Age { get; set; }
        public Gender StudentGender { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            IList<Student> studentList = new List<Student>() {
            new Student() { StudentID = 1, StudentName = "John", StudentGender = Gender.MALE } ,
            new Student() { StudentID = 2, StudentName = "Moin",  StudentGender = Gender.MALE } ,
            new Student() { StudentID = 3, StudentName = "Bill",  StudentGender =  Gender.TRANSGENDER} ,
            new Student() { StudentID = 4, StudentName = "Michelle" , StudentGender = Gender.FEMALE} ,
            new Student() { StudentID = 5, StudentName = "Els" ,StudentGender = Gender.FEMALE}
        };

            // returns collection of anonymous objects with Name and Age property
            //var selectResult = from s in studentList
            //                   let prefix = s.StudentGender==Gender.FEMALE? "Mss.":"Mr."
            //                   select new { Name = prefix + s.StudentName, Age = s.Age };
            var selectResult = from s in studentList
                               let prefix = s.StudentGender == Gender.FEMALE ? "Mss":s.StudentGender==Gender.TRANSGENDER? "IT. " : "Mr."
                               select new { Name = prefix + s.StudentName, Age = s.Age };
            foreach (var s in selectResult)
            {
                Console.WriteLine(s);
            }
        }
    }
}
