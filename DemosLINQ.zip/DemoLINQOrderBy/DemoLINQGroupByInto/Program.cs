﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DemoLINQGroupByInto
{
    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public byte Age { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Demo1();
            Demo2();
        }

        private static void Demo2()
        {
            IList<Student> studentList = new List<Student>() {
            new Student() { StudentID = 1, StudentName = "John", Age = 18 } ,
            new Student() { StudentID = 2, StudentName = "Steve",  Age = 18 } ,
            new Student() { StudentID = 3, StudentName = "Bill",  Age = 20 } ,
            new Student() { StudentID = 4, StudentName = "Ram" , Age = 19 } ,
            new Student() { StudentID = 5, StudentName = "Ron" , Age = 19 },
            new Student() { StudentID = 6, StudentName = "Sam" , Age = 19 }};

            var result = from student in studentList
                         group student by student.Age into studentAgeGroup
                         select studentAgeGroup;
            Console.Write("Students groups by age:\n");
            foreach (var studentAgeGroupList in result)
            {
                Console.WriteLine("Students group on age: " + studentAgeGroupList.Key + " number of students in group: " + studentAgeGroupList.Count() );
                Console.WriteLine("Students in this group:");
                foreach (Student s in studentAgeGroupList)
                {
                    Console.WriteLine($"{s.StudentName} age: {s.Age}");
                }
            }
        }

        static void Demo1()
        {
            List<string> studenten = new List<string>();
            studenten.Add("Bill");
            studenten.Add("Adam");
            studenten.Add("Bill");
            studenten.Add("Jos");

            var result = from s in studenten
                         group s by s into listStudents
                         select listStudents;
            Console.Write("The frequency of the student names are :\n");
            foreach (var listStudents in result)
            {
                Console.WriteLine("Character " + listStudents.Key + ": " + listStudents.Count() + " times");
            }
        }
    }
}
