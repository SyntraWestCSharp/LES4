﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DemoLINQOrderBy
{
    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public byte Age { get; set; }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Demo1();
        }

        private static void Demo1()
        {
            IList<Student> studentList = new List<Student>() {
            new Student() { StudentID = 1, StudentName = "John", Age = 18 } ,
            new Student() { StudentID = 2, StudentName = "Steve",  Age = 15 } ,
            new Student() { StudentID = 3, StudentName = "Bill",  Age = 25 } ,
            new Student() { StudentID = 4, StudentName = "Bill" , Age = 20 } ,
            new Student() { StudentID = 5, StudentName = "Ron" , Age = 19 }
            };
            var studentsInAscOrder = studentList.OrderBy(s => s.StudentName).ThenBy(s=> s.Age);
            foreach (var s in studentsInAscOrder)
            {
                Console.WriteLine(s.StudentName + " age: " + s.Age);
            }
        }
    }

 
}
